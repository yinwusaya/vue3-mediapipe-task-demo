import { describe, expect, it } from 'vitest'

describe('hi', () => {
  it('should works', () => {
    expect(1 + 1).toEqual(2)
  })
})
