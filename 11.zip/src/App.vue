<template>
  <main font-sans text="center gray-700 dark:gray-200">
    <RouterView />
    <!-- <TheFooter /> -->
  </main>
</template>
